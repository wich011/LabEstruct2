﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace BueLFA
{
    public class Arbol
    {
        #region CAMPOS DE CLASE
        //Insercion en cola
        private string precedencia = "(|.";
        private string[] delimitadores = { "|", "*", ".", "(", ")" };
        private string[] operandosArray;
        private string[] operadoresArray;
        private char[] charoperador;
        private string[] operadoresArrayFinal;
        string operadores;
        int contoperadores = 0;
        int contraoperandos = 0;
        public string[] cad = new string[1000];
        public bool[] cadN = new bool[1000];
        public string[] cadF = new string[1000];
        public string[] cadL = new string[1000];
        string acF = "", acO = "", acO2 = "", acA = "", acA2= "", acC = "", acC2 = "";
        string acL = "";
        private Queue colaExpresion;

        //CREACION ARBOL
        private string token;
        private string operadorTemp;
        private int i = 0;
        private Stack pilaOperadores;
        private Stack pilaOperandos;
        private Stack pilaDor;
        private Nodo raiz = null;
        public Nodo nodoDot { get; set; }

        //PROPIEDADES PARA RECORRIDOS
        public string cadenaPreorden { get; set; }
        public string cadenaInorden { get; set; }
        public string cadenaPostorden { get; set; }

        

        #endregion

        #region CONSTRUCTORES
        public Arbol()
        {
            pilaOperadores = new Stack();
            pilaOperandos = new Stack();
            pilaDor = new Stack();
            colaExpresion = new Queue();
        }
        #endregion

        #region INSERCION EN COLA
        public void InsertarEnCola(string expresion)
        {
            operandosArray = expresion.Split(delimitadores, StringSplitOptions.RemoveEmptyEntries);
            operadoresArray = expresion.Split(operandosArray, StringSplitOptions.RemoveEmptyEntries);
            operadores = String.Concat(operadoresArray);
            charoperador = operadores.ToCharArray();
            operadoresArrayFinal = new string[charoperador.Length];
            for (int i = 0; i < operadoresArrayFinal.Length; i++)
            {
                string valor = charoperador[i].ToString();
                operadoresArrayFinal[i] = valor;
            }
            int conta = 0;
            char[] expres = expresion.ToCharArray();
            while (colaExpresion.Count < operandosArray.Length + operadoresArrayFinal.Length)
            {
                if (expres[conta].ToString() == operadoresArrayFinal[contoperadores])
                {
                    colaExpresion.Enqueue(operadoresArrayFinal[contoperadores]);
                    if (contoperadores + 1 != operadoresArrayFinal.Length)
                    {
                        contoperadores++;
                    }
                    conta++;
                }
                else
                {
                    colaExpresion.Enqueue(operandosArray[contraoperandos]);
                    if (operandosArray[contraoperandos].Length > 1)
                    {
                        conta = conta + operandosArray[contraoperandos].Length;
                    }
                    else
                    {
                        conta++;
                    }
                    if (contraoperandos + 1 != operandosArray.Length)
                    {
                        contraoperandos++;
                    }
                }

            }
            // colaExpresion.Enqueue(operadoresArrayFinal[operadoresArrayFinal.Length - 1]);
        }
        #endregion

        #region ARBOL
        public Nodo CrearArbol()
        {
            while (colaExpresion.Count != 0)
            {
                token = (string)colaExpresion.Dequeue();
                if (token == "(")
                {
                    pilaOperadores.Push(token);
                }
                else if (token == ")")
                {
                    operadorTemp = (string)pilaOperadores.Peek();
                    while (pilaOperadores.Count != 0 && operadorTemp != "(")
                    {
                        GuardaSubArbol();
                        if (pilaOperadores.Count != 0)
                        {
                            operadorTemp = (string)pilaOperadores.Peek();
                        }
                    }
                    pilaOperadores.Pop();
                }
                else if (token == "*" || token == "+")
                {
                    pilaOperadores.Push(token);
                    GuardarSubArbolUnario();
                }
                else if (precedencia.IndexOf(token) < 0)
                {
                    pilaOperandos.Push(new Nodo(token));
                    pilaDor.Push(new Nodo($"nodo{++i}[label=\"{token}\"]"));

                }
                else
                {
                    if (pilaOperadores.Count != 0)
                    {
                        operadorTemp = (string)pilaOperadores.Peek();
                        while (pilaOperadores.Count != 0 && precedencia.IndexOf(operadorTemp) >= precedencia.IndexOf(token))
                        {
                            GuardaSubArbol();
                            if (pilaOperadores.Count != 0)
                            {
                                operadorTemp = (string)pilaOperadores.Peek();

                            }
                        }
                    }
                    pilaOperadores.Push(token);
                }

            }

            raiz = (Nodo)pilaOperandos.Peek();
            nodoDot = (Nodo)pilaDor.Peek();
            while (pilaOperadores.Count != 0)
            {
                GuardaSubArbol();
                raiz = (Nodo)pilaOperandos.Peek();
                nodoDot = (Nodo)pilaDor.Peek();

            }
            return raiz;
        }

        private void GuardaSubArbol()
        {
            Nodo derecho = (Nodo)pilaOperandos.Pop();
            Nodo izquierdo = (Nodo)pilaOperandos.Pop();
            pilaOperandos.Push(new Nodo(derecho, izquierdo, pilaOperadores.Peek()));

            Nodo derechoG = (Nodo)pilaDor.Pop();
            Nodo izquierdoG = (Nodo)pilaDor.Pop();
            pilaDor.Push(new Nodo(derechoG, izquierdoG, $"nodo{++i}[label=\"{pilaOperadores.Pop()}\"]"));
        }

        private void GuardarSubArbolUnario()
        {
            Nodo izquierdo = (Nodo)pilaOperandos.Pop();
            pilaOperandos.Push(new Nodo(null, izquierdo, pilaOperadores.Peek()));

            Nodo izquierdoG = (Nodo)pilaDor.Pop();
            pilaDor.Push(new Nodo(null, izquierdoG, $"nodo{++i}[label=\"{pilaOperadores.Pop()}\"]"));
        }
        #endregion

        #region RECORRIDOS
        //PREORDER
        public string InsertarPre(Nodo tree)
        {
            if (tree != null)
            {
                cadenaPreorden += tree.Datos + " ";
                InsertarPre(tree.NodoIzquierd);
                InsertarPre(tree.NodoDerecho);

            }
            return cadenaPreorden;
        }
        //INORDER
        public string InsertaIn(Nodo tree)
        {
            if (tree != null)
            {
                InsertaIn(tree.NodoIzquierd);
                cadenaInorden += tree.Datos + " ";
                InsertaIn(tree.NodoDerecho);

            }
            return cadenaInorden;
        }
        int cont = 0;
        int cont2 = 0;
        int cont3 = 0;
        //POSTORDER
        public string InsertaPost(Nodo tree)
        {
            if (tree != null)
            {
                tree.Nulleable = false;
                InsertaPost(tree.NodoIzquierd); 
                acO += acF + ", ";
                
                
                InsertaPost(tree.NodoDerecho);
                if (tree.NodoDerecho != null)
                {
                    acO2 += acL + ", ";
                }
                if (tree.NodoIzquierd != null && tree.Datos.ToString() == "*")
                {
                    acA += acF + ", ";
                }
                cadenaPostorden += tree.Datos + " ";
              
                cad[cont] = tree.Datos.ToString();
                cont++;
                if (tree.NodoDerecho == null && tree.NodoIzquierd == null)
                {
                    cont2++;
                    tree.First = cont2.ToString();
                    acF = tree.First.ToString();
                    cadF[cont3] = acF;
                   
                    tree.Last = cont2.ToString();
                    acL = tree.First.ToString();
                    cadL[cont3] = acL;
                    tree.Nulleable = false;

                    cadN[cont] = false;
                    cont3++;
                    //NULLABLES
                }if(tree.Datos != null && tree.Datos.ToString() == "*")
                {
                    tree.Nulleable = true;
                    cadN[cont] = true;
                }
                if (tree.Datos != null && tree.Datos.ToString() == ".")
                {
                    if (cadN[cont-1] == true &&  cadN[cont-2] == true)
                    {
                        tree.Nulleable = true;
                        cadN[cont] = true;
                    }
                   
                }
                if (tree.Datos != null && tree.Datos.ToString() == "|")
                {
                    if (cadN[cont - 1] == true || cadN[cont - 2] == true)
                    {
                        tree.Nulleable = true;
                        cadN[cont] = true;
                    }
                }
                //FIRST
                if (tree.Datos != null && tree.Datos.ToString() == "|")
                {
                    

                    
                    
                    cadF[cont3] = acO;
                    cadL[cont3] = acO2;
                    cont3++;
                }
                if (tree.Datos != null && tree.Datos.ToString() == ".")
                {
                    
                    

                    
                    cadF[cont3] = acA;
                    cadL[cont3] = acO;
                    cont3++;
                }
                if (tree.Datos != null && tree.Datos.ToString() == "*")
                {


                   
                    
                    cadF[cont3] = acA;
                    cadL[cont3] = acA;
                    cont3++;
                }
            }
            return cadenaPostorden;
        }
        #endregion

        public void Limpiar()
        {
            cadenaPreorden = "";
            cadenaInorden = "";
            cadenaPostorden = "";
        }
    }
}
