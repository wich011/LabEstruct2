﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BueLFA
{
    public partial class Form1 : Form
    {
        string archivo;
        string sinespacios;
        string final;
        string inner = "";
        string line;
        string expresion = "";
        private Nodo raiz;
        private Arbol arbol;
        private Nodo nod;
        string[] cad2 = new string[1000];
        bool[] cadN2 = new bool[1000];
        string[] cadF2 = new string[1000];
        string[] cadL2 = new string[1000];
        int conta = 0;

        public Form1()
        {
            InitializeComponent();
            arbol = new Arbol();
            nod = new Nodo();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            archivo = textBox1.Text;
            try
            {
                StreamReader sr = new StreamReader(archivo);//Lee el archivo segun la direccion
                line = sr.ReadLine();
                while (line != null)
                {
                    inner += line + "\n";//Guarda el contenido del archivo en una variable string con salto de linea del final de cada ciclo
                    line = sr.ReadLine();
                }
            }
            catch (Exception)
            {
            }
            sinespacios = inner.Replace(" ", String.Empty); //Elimina los espacios en blanco introducidos por la tecla SPACE
            final = sinespacios.Replace("\t", String.Empty);//Elimina las tabulaciones generadas por la tecla TAB
            if (Regex.IsMatch(final, "^(SETS(\\n)*(([A-Z])+=((('([A-Z]|[a-z]|[0-9])'\\.\\.'([A-Z]|[a-z]|[0-9])'|'_')(\\+)?)+(\\n)*|CHR\\(([0-9])*\\)\\.\\.CHR\\(([0-9])*\\)(\\n)?))+(\\n)*)?(\\n)*TOKENS(\\n)*(TOKEN[0-9]*\\=([A-Z]+|\\{RESERVADAS\\(\\)([A-Z]*\\(\\))*\\}|\\((([A-Z])+|\\||\\*|\\+)+\\)|(\\*|\\+|\\|)?|\\'(\\\"|[A-Z]|\\'|\\=|\\<|\\>|\\+|\\-|\\*|\\(|\\)|\\;|\\.|\\{|\\}|\\[|\\]|\\:|\\,)\\')+(\\n)*)+ACTIONS(\\n)*RESERVADAS\\(\\)(\\n)+\\{\\n+([0-9]*\\=\\'[A-Z]+\\'\\n+)+\\}\\n+([A-Z]*\\(\\)\\n+\\{\\n+([0-9]*\\=\\'[A-Z]*\\'\\n+)+\\}\\n+)*[A-Z]*ERROR\\=[0-9]+\\n*?"))//Expresión que evalua el contenido de la cadena
            {
                try
                {
                    StreamReader sr = new StreamReader(archivo);//Lee el archivo segun la direccion
                    line = sr.ReadLine();
                    while (line != null)
                    {
                        if (Regex.IsMatch(line, "^(\\s)*TOKEN(\\s)*[0-9]+(\\s)*\\="))
                        {
                            string[] aux = line.Split("= ");
                            string evaular = aux[1];
                            string evaluarf = evaular.Replace('.', '4');
                            evaluarf = evaluarf.Replace("\t", String.Empty);
                            expresion += evaluarf + '|';
                        }
                        line = sr.ReadLine();
                    }
                }
                catch (Exception)
                {
                }
                char[] evaluar = expresion.ToCharArray();
                for (int i = 0; i < expresion.Length; i++)
                {
                    if (i > 0 && i < expresion.Length - 1)
                    {
                        if (evaluar[i] == ' ' && evaluar[i - 1] != '(' && evaluar[i - 1] != '{' && evaluar[i - 1] != '|' && evaluar[i + 1] != '*' && evaluar[i + 1] != ')' && evaluar[i + 1] != ' ' && evaluar[i + 1] != '}' && evaluar[i + 1] != '|')
                        {
                            evaluar[i] = '.';
                        }
                        if (evaluar[i] == '(' && ((evaluar[i - 1] == '\'' && evaluar[i + 1] == '\'') || evaluar[i + 1] == ')'))
                        {
                            evaluar[i] = '1';
                        }
                        if (evaluar[i] == ')' && ((evaluar[i - 1] == '\'' && evaluar[i + 1] == '\'') || evaluar[i - 1] == '1'))
                        {
                            evaluar[i] = '2';
                        }
                        if (evaluar[i] == '*' && evaluar[i - 1] == '\'' && evaluar[i + 1] == '\'')
                        {
                            evaluar[i] = '3';
                        }
                    }
                }
                evaluar[expresion.Length - 1] = ' ';
                expresion = new string(evaluar);
                expresion = expresion.Replace(" ", String.Empty);
                expresion = "(" + expresion + ").#";
                arbol.InsertarEnCola(expresion);
                raiz = arbol.CrearArbol();
                label1.Text = arbol.InsertaPost(raiz);
                do
                {
                    cad2[conta] = arbol.cad[conta];
                    listBox1.Items.Add(cad2[conta] + "\n");

                    cadN2[conta] = arbol.cadN[conta];
                    listBox4.Items.Add(cadN2[conta] + "\n");

                    cadF2[conta] = arbol.cadF[conta];
                    listBox2.Items.Add(cadF2[conta] + "\n");

                    cadL2[conta] = arbol.cadL[conta];
                    listBox3.Items.Add(cadL2[conta] + "\n");
                    conta++;
                    
                } while (arbol.cad[conta]!=null);
               
                
                
            }
            else
            {
                MessageBox.Show("Mensaje no leido correctamente"); //De lo contrario mostrara este mensaje
            }
        }
    }
    public static class Extensions
    {
        public static string[] Split(this string str, string separator)
        {
            return str.Split(new string[] { separator }, StringSplitOptions.None);
        }
    }
}
