﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BueLFA
{
    public class Nodo
    {
        #region CAMPOS DE CLASE
        private Object datos;
        private Nodo nodoIzquierdo;
        private Nodo nodoDerecho;
        private string first;
        private string last;
        private bool nulleable;
        #endregion

        #region CONSTRUCTORES
        public Nodo()
        {
            nodoDerecho = nodoIzquierdo = null;
        }

        public Nodo(object datos)
        {
            this.datos = datos;
            nodoDerecho = nodoIzquierdo = null;
            first = "";
            last = "";
            nulleable = false;
        }

        public Nodo(Nodo derecho, Nodo izquierdo, object valor)
        {
            this.nodoDerecho = derecho;
            this.nodoIzquierdo = izquierdo;
            this.datos = valor;
            first = "";
            last = "";
            nulleable = false;
        }
        #endregion

        #region PROPIEDADES DEL NODO
        //Nodo Izquierdo
        public Nodo NodoIzquierd { get => nodoIzquierdo; set => nodoIzquierdo = value; }
        //Nodo Derecho
        public Nodo NodoDerecho { get => nodoDerecho; set => nodoDerecho = value; }
        //Datos
        public Object Datos { get => datos; set => datos = value; }
        public string First { get => first; set => first = value; }
        public string Last { get => last; set => last = value; }
        public bool Nulleable { get => nulleable; set => nulleable = value; }
        #endregion
    }
}

